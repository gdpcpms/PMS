// JavaScript Document
var	departmentArray;
var	positionArray;
var employeeArray;
$(document).ready(function(e) {
	//从数据库员工表导入考勤信息
	init();
	//从部门表导入已有部门号，目前定为1-10;
	departmentArray=[1,2,3,4,5,6,7,8,9,10];
	//从岗位表导入已有岗位号，目前定为1-10;
	positionArray=[1,2,3,4,5,6,7,8,9,10];
	//从员工表导入已有员工号，目前定为1-10;
	employeeArray=[1,2,3,4,5,6,7,8,9,10];
	//从员工表导入员工号姓名部门岗位的对应关系
	ENPD_Array=[[1,'aa',1,1],[2,'bb',2,2],[3,'dd',3,3],[4,'ee',4,4],[5,'ff',5,5],[6,'gg',6,6],[7,'hh',7,7],[8,'ii',8,8],[9,'jj',9,9],[10,'kk',10,10]];
	//表格头部固定在顶部
	$(".attendance_table").scroll(function(){
		var a=$(".attendance_table").scrollTop();
		if(a>=35){
			$("#attendance_table_header").removeClass("hide");
			$("#attendance_table_header").children().width($("#attendance_table_content").children().children().width())
		}
		else{
			$("#attendance_table_header").addClass("hide");
		}
	});
	$("#AttendanceNo").on("focus",add());
});
//导入考勤信息
function init(){}

function addcheckOK(){
	if($("#AttendanceNo").val().replace(/^ +| +$/g,'')==''){
		 alert('出勤编号不能为空!');
		 $("#AttendanceNo").focus(); 
		 return false;
	}
	var AttendanceNo=$("#AttendanceNo").val();
	if($(".attendance-"+AttendanceNo).length>0){
		alert('出勤编号已存在!'); 
		$("#AttendanceNo").focus(); 
		return false;
	}
	if($("#EmployeeID").val().replace(/^ +| +$/g,'')==''){
		 alert('员工号不能为空!');
		 $("#EmployeeID").focus(); 
		 return false;
	}
	var hasEmployee=0;
	for(var i=0;i<employeeArray.length;i++){
		if(employeeArray[i]==$("#EmployeeID").val()){
			hasEmployee=1; break;
		}
	}
	if(hasEmployee==0){
		$("#EmployeeID").focus(); 
		alert("您输入的员工不存在");
		return false;
	}
	if($("#Name").val().replace(/^ +| +$/g,'')==''){
		 alert('员工姓名不能为空!');
		 $("#Name").focus(); 
		 return false;
	}
	if($("#DepartmentID").val().replace(/^ +| +$/g,'')==''){
		 alert('部门号不能为空!');
		 $("#DepartmentID").focus(); 
		 return false;
	}
	if(!$("#DepartmentID").val().replace(/^[0-9]*$/g,'')==''){
		 alert('部门号只能为数字!'); 
		 $("#DepartmentID").focus(); 
		 return false;
	}
	var hasDepartment=0;
	for(var i=0;i<departmentArray.length;i++){
		if(departmentArray[i]==$("#DepartmentID").val()){
			hasDepartment=1; break;
		}
	}
	if(hasDepartment==0){
		$("#DepartmentID").focus(); 
		alert("您输入的部门不存在");
		return false;
	}
	if($("#PositionID").val().replace(/^ +| +$/g,'')==''){
		 alert('岗位号不能为空!');
		 $("#PositionID").focus(); 
		 return false;
	}
	if(!$("#PositionID").val().replace(/^[0-9]*$/g,'')==''){
		 alert('岗位号只能为数字!'); 
		 $("#PositionID").focus(); 
		 return false;
	}
	var hasPosition=0;
	for(var i=0;i<positionArray.length;i++){
		if(positionArray[i]==$("#PositionID").val()){
			hasPosition=1; break;
		}
	}
	if(hasPosition==0){
		alert("您输入的岗位不存在");
		$("#PositionID").focus(); 
		return false;
	}
	if($("#AttendanceDay").val().replace(/^ +| +$/g,'')==''){
		 alert('日期不能为空!');
		 $("#AttendanceDay").focus(); 
		 return false;
	}
	if(!$("#AttendanceDay").val().replace(/^\d{4}-\d{1,2}-\d{1,2}/g,'')==''){
		 alert('请按2000-01-01的格式输入日期');
		 $("#AttendanceDay").focus(); 
		 return false;
	}
	return true;
}

function renewcheckOK(){
	if($("#renewAttendanceNo").val().replace(/^ +| +$/g,'')==''){
		 alert('出勤编号不能为空!');
		 $("#renewAttendanceNo").focus(); 
		 return false;
	}
	if($("#renewEmployeeID").val().replace(/^ +| +$/g,'')==''){
		 alert('员工号不能为空!');
		 $("#renewEmployeeID").focus(); 
		 return false;
	}
	var hasEmployee=0;
	for(var i=0;i<employeeArray.length;i++){
		if(employeeArray[i]==$("#renewEmployeeID").val()){
			hasEmployee=1; break;
		}
	}
	if(hasEmployee==0){
		$("#renewEmployeeID").focus(); 
		alert("您输入的员工不存在");
		return false;
	}
	if($("#renewName").val().replace(/^ +| +$/g,'')==''){
		 alert('员工姓名不能为空!');
		 $("#renewName").focus(); 
		 return false;
	}
	if($("#renewDepartmentID").val().replace(/^ +| +$/g,'')==''){
		 alert('部门号不能为空!');
		 $("#renewDepartmentID").focus(); 
		 return false;
	}
	var hasDepartment=0;
	for(var i=0;i<departmentArray.length;i++){
		if(departmentArray[i]==$("#renewDepartmentID").val()){
			hasDepartment=1; break;
		}
	}
	if(hasDepartment==0){
		$("#renewDepartmentID").focus(); 
		alert("您输入的部门不存在");
		return false;
	}
	if(!$("#renewDepartmentID").val().replace(/^[0-9]*$/g,'')==''){
		 alert('部门号只能为数字!'); 
		 $("#renewDepartmentID").focus(); 
		 return false;
	}
	if($("#renewPositionID").val().replace(/^ +| +$/g,'')==''){
		 alert('岗位号不能为空!');
		 $("#renewPositionID").focus(); 
		 return false;
	}
	var hasPosition=0;
	for(var i=0;i<positionArray.length;i++){
		if(positionArray[i]==$("#renewPositionID").val()){
			hasPosition=1; break;
		}
	}
	if(hasPosition==0){
		alert("您输入的岗位不存在");
		$("#renewPositionID").focus(); 
		return false;
	}
	if(!$("#renewPositionID").val().replace(/^[0-9]*$/g,'')==''){
		 alert('岗位号只能为数字!'); 
		 $("#renewPositionID").focus(); 
		 return false;
	}
	if($("#renewAttendanceDay").val().replace(/^ +| +$/g,'')==''){
		 alert('日期不能为空!');
		 $("#renewAttendanceDay").focus(); 
		 return false;
	}
	if(!$("#renewAttendanceDay").val().replace(/^\d{4}-\d{1,2}-\d{1,2}/g,'')==''){
		 alert('请按2000-01-01的格式输入日期');
		 $("#renewAttendanceDay").focus(); 
		 return false;
	}
	return true;
}

//输入员工号后同步员工姓名，岗位号，部门号
function ENPD(){
	var addsyn=setInterval(function(){
		if($("#EmployeeID").val()!=""&&!$("#EmployeeID").is(":focus")){
			var hasEmployee=0;
			for(var i=0;i<ENPD_Array.length;i++){
				if($("#EmployeeID").val()==ENPD_Array[i][0]){
					$("#Name").val(ENPD_Array[i][1]);
					$("#DepartmentID").val(ENPD_Array[i][2]);
					$("#PositionID").val(ENPD_Array[i][3]);
					hasEmployee=1;
					clearInterval(addsyn);
					break;
				}
			}
			clearInterval(addsyn);
		}
	},500);
	var renewsyn=setInterval(function(){
		if($("#renewEmployeeID").val()!=""&&!$("#renewEmployeeID").is(":focus")){
			for(var i=0;i<ENPD_Array.length;i++){
				if($("#renewEmployeeID").val()==ENPD_Array[i][0]){
					$("#renewName").val(ENPD_Array[i][1]);
					$("#renewDepartmentID").val(ENPD_Array[i][2]);
					$("#renewPositionID").val(ENPD_Array[i][3]);
					clearInterval(renewsyn);
					break;
				}
			}
		}
	},500);
}

//增加
function add(){
	$(".attendance_table").scrollTop($("#attendance_table_content").children().length*38);
	$("#AttendanceNo").focus();
	$(document).keydown(function(e){
		var key=e.keyCode;
		if(key==13){
			if(addcheckOK()){
				var AttendanceNo=$("#AttendanceNo").val();
				var EmployeeID=$("#EmployeeID").val();
				var Name=$("#Name").val();
				var DepartmentID=$("#DepartmentID").val();
				var PositionID=$("#PositionID").val();
				var AttendanceDay=$("#AttendanceDay").val();
				$("#attendance_table_content").append('<tr class="attendance-'+AttendanceNo+'"><td >'+AttendanceNo+'</td><td >'+EmployeeID+'</td><td>'+Name+'</td><td >'+DepartmentID+'</td><td >'+PositionID+'</td><td >'+AttendanceDay+'</td></tr>');
				$("#AttendanceNo").val("");
				$("#AttendanceNo").focus();
				$("#EmployeeID").val("");
				$("#Name").val("");
				$("#DepartmentID").val("");
				$("#PositionID").val("");
				$("#AttendanceDay").val("");
				//输入后滚动条自动到底部
				$(".attendance_table").scrollTop($(".attendance_table").scrollTop()+100);
			}
		}
	})
}

//查找
function lookup(){
	//获取输入的部门号
	var input_text=$("#input_text").val();
	//指定行存在
	if($(".attendance-"+input_text).length>0){
		//根据输入部门号跳转到指定的行
		var counts=$(".attendance-"+input_text).prevAll().length;
		$(".attendance_table").scrollTop((counts-4)*37);
		//指定行文字变红1.5秒
		$(".attendance-"+input_text).css("color","#fF0000");	
		setTimeout(function(){
			$(".attendance-"+input_text).css("color","#333");	
		},1500);
		
	}
	//指定行不存在，提示2秒
	else{
		$("#alert").removeClass("hide");
		setTimeout(function(){
			$("#alert").addClass("hide");
		},2000);
	}
	/*//清空输入框
	$("#input_text").val("");
	$("#input_text").focus();*/
}

//修改
function renew(){
	//获取输入的部门号
	var input_text=$("#input_text").val();
	//指定行存在
	if($(".attendance-"+input_text).length>0){
		//1.记录原来的信息
		var texts=$(".attendance-"+input_text).children();
		var AttendanceNo=texts.eq(0).text();
		var EmployeeID=texts.eq(1).text();
		var Name=texts.eq(2).text();
		var DepartmentID=texts.eq(3).text();
		var PositionID=texts.eq(4).text();
		var AttendanceDay=texts.eq(5).text();
		//2.将改行转化为文本框
		$(".attendance-"+input_text).empty();
		$(".attendance-"+input_text).append('<td><input type="text" class="form-control" id="renewAttendanceNo"></td><td><input type="text" class="form-control" id="renewEmployeeID" onFocus="ENPD()"></td><td><input type="text" class="form-control" id="renewName" disabled></td><td><input type="text" class="form-control" id="renewDepartmentID" disabled></td><td><input type="text" class="form-control" id="renewPositionID" disabled></td><td><input type="text" class="form-control" id="renewAttendanceDay"></td>');
		//3.在文本框中显示原来的信息
		$("#renewAttendanceNo").focus();
		$("#renewAttendanceNo").val(AttendanceNo);
		$("#renewEmployeeID").val(EmployeeID);
		$("#renewName").val(Name);
		$("#renewDepartmentID").val(DepartmentID);
		$("#renewPositionID").val(PositionID);
		$("#renewAttendanceDay").val(AttendanceDay);
		$("#renewAttendanceNo").blur(function(){
			if(AttendanceNo!=$("#renewAttendanceNo").val()&&$(".attendance-"+$("#renewAttendanceNo").val()).length>0){
			alert("出勤编号已存在");
			$("#renewAttendanceNo").val(AttendanceNo);
			$("#renewAttendanceNo").focus();
			}
		})
		//4.文本框失去焦点时保存修改信息
		var time=setInterval(function(){
			if(!$("#renewAttendanceNo").is(":focus")&&!$("#renewEmployeeID").is(":focus")&&!$("#renewName").is(":focus")&&!$("#renewDepartmentID").is(":focus")&&!$("#renewPositionID").is(":focus")&&!$("#renewAttendanceDay").is(":focus")){
				if(renewcheckOK()){
					var AttendanceNo=$("#renewAttendanceNo").val();
					var EmployeeID=$("#renewEmployeeID").val();
					var Name=$("#renewName").val();
					var DepartmentID=$("#renewDepartmentID").val();
					var PositionID=$("#renewPositionID").val();
					var AttendanceDay=$("#renewAttendanceDay").val();
	
					$(".attendance-"+input_text).empty();
					$(".attendance-"+input_text).append('<td>'+AttendanceNo+'</td><td>'+EmployeeID+'</td><td>'+Name+'</td><td>'+DepartmentID+'</td><td>'+PositionID+'</td><td>'+AttendanceDay+'</td>');
					clearInterval(time);
					if(AttendanceNo!=input_text){
						$(".attendance-"+input_text).addClass("attendance-"+AttendanceNo);
						$(".attendance-"+input_text).removeClass("attendance-"+input_text);
					}
				}
			}
		},200);
	}
	//指定行不存在
	else{
		$("#alert").removeClass("hide");
		setTimeout(function(){
			$("#alert").addClass("hide");
		},2000);
		return;
	}
}

//删除
function delect(){
	//获取输入的部门号
	var input_text=$("#input_text").val();
	//指定行存在
	if($(".attendance-"+input_text).length>0){
		//根据输入部门号跳转到指定的行，指定行文字变红
		var counts=$(".attendance-"+input_text).prevAll().length;
		$(".attendance_table").scrollTop((counts-4)*37);
		$(".attendance-"+input_text).css("color","#fF0000");	
		//弹出框提问是否删除
		setTimeout(function(){
			if(confirm("是否确定删除")){
				$(".attendance-"+input_text).remove();
			}
			else{
				$(".attendance-"+input_text).css("color","#333");	
			}
		},500);
	}
	//指定行不存在
	else{
		$("#alert").removeClass("hide");
		setTimeout(function(){
			$("#alert").addClass("hide");
		},2000);
		return;
	}
}
