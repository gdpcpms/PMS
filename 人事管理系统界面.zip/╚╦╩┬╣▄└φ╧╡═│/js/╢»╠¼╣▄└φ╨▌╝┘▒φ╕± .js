// JavaScript Document
var	departmentArray;
var	positionArray;
var employeeArray;
var ENPD_Array;	//记录员工号姓名部门岗位的对应关系

//初始化
$(document).ready(function(e) {
	//从数据库员工表导入工信休假息
	init();
	//从部门表导入已有部门号，目前定为1-10;
	departmentArray=[1,2,3,4,5,6,7,8,9,10];
	//从岗位表导入已有岗位号，目前定为1-10;
	positionArray=[1,2,3,4,5,6,7,8,9,10];
	//从员工表导入已有员工号，目前定为1-10;
	employeeArray=[1,2,3,4,5,6,7,8,9,10];
	//从员工表导入员工号姓名部门岗位的对应关系
	ENPD_Array=[[1,'aa',1,1],[2,'bb',2,2],[3,'dd',3,3],[4,'ee',4,4],[5,'ff',5,5],[6,'gg',6,6],[7,'hh',7,7],[8,'ii',8,8],[9,'jj',9,9],[10,'kk',10,10]];
	//表格头部固定在顶部
	$(".leave_table").scroll(function(){
		var a=$(".leave_table").scrollTop();
		if(a>=35){
			$("#leave_table_header").removeClass("hide");
			$("#leave_table_header").children().width($("#leave_table_content").children().children().width())
		}
		else{
			$("#leave_table_header").addClass("hide");
		}
	});
	$("#LeaveNo").on("focus",add());
});

//导入休假信息
function init(){}

function addcheckOK(){
	if($("#LeaveNo").val().replace(/^ +| +$/g,'')==''){
		 alert('请假编号不能为空!');
		 $("#LeaveNo").focus(); 
		 return false;
	}
	if(!$("#LeaveNo").val().replace(/^[0-9]*$/g,'')==''){
		 alert('请假编号只能为数字!'); 
		 $("#LeaveNo").focus(); 
		 return false;
	}
	var LeaveNo=$("#LeaveNo").val();
	if($(".leave-"+LeaveNo).length>0){
		alert('请假编号已存在!'); 
		$("#LeaveNo").focus(); 
		return false;
	}
	if($("#EmployeeID").val().replace(/^ +| +$/g,'')==''){
		 alert('员工号不能为空!');
		 $("#EmployeeID").focus(); 
		 return false;
	}
	if(!$("#EmployeeID").val().replace(/^[0-9]*$/g,'')==''){
		 alert('员工号只能为数字!'); 
		 $("#EmployeeID").focus(); 
		 return false;
	}
	var hasEmployee=0;
	for(var i=0;i<employeeArray.length;i++){
		if(employeeArray[i]==$("#EmployeeID").val()){
			hasEmployee=1; break;
		}
	}
	if(hasEmployee==0){
		$("#EmployeeID").focus(); 
		alert("您输入的员工不存在");
		return false;
	}
	if($("#Name").val().replace(/^ +| +$/g,'')==''){
		 alert('员工姓名不能为空!');
		 $("#Name").focus(); 
		 return false;
	}
	if($("#DepartmentID").val().replace(/^ +| +$/g,'')==''){
		 alert('部门号不能为空!');
		 $("#DepartmentID").focus(); 
		 return false;
	}
	if(!$("#DepartmentID").val().replace(/^[0-9]*$/g,'')==''){
		 alert('部门号只能为数字!'); 
		 $("#DepartmentID").focus(); 
		 return false;
	}
	var hasDepartment=0;
	for(var i=0;i<departmentArray.length;i++){
		if(departmentArray[i]==$("#DepartmentID").val()){
			hasDepartment=1; break;
		}
	}
	if(hasDepartment==0){
		$("#DepartmentID").focus(); 
		alert("您输入的部门不存在");
		return false;
	}
	if($("#PositionID").val().replace(/^ +| +$/g,'')==''){
		 alert('岗位号不能为空!');
		 $("#PositionID").focus(); 
		 return false;
	}
	if(!$("#PositionID").val().replace(/^[0-9]*$/g,'')==''){
		 alert('岗位号只能为数字!'); 
		 $("#PositionID").focus(); 
		 return false;
	}
	var hasPosition=0;
	for(var i=0;i<positionArray.length;i++){
		if(positionArray[i]==$("#PositionID").val()){
			hasPosition=1; break;
		}
	}
	if(hasPosition==0){
		alert("您输入的岗位不存在");
		$("#PositionID").focus(); 
		return false;
	}
	if($("#LeaveReason").val().replace(/^ +| +$/g,'')==''){
		 alert('请假原因不能为空!');
		 $("#LeaveReason").focus(); 
		 return false;
	}
	if($("#LeaveTime").val().replace(/^ +| +$/g,'')==''){
		 alert('日期不能为空!');
		 $("#LeaveTime").focus(); 
		 return false;
	}
	if(!$("#LeaveTime").val().replace(/^\d{4}-\d{1,2}-\d{1,2}/g,'')==''){
		 alert('请按2000-01-01的格式输入日期');
		 $("#LeaveTime").focus(); 
		 return false;
	}
	if($("#LeaveDay").val().replace(/^ +| +$/g,'')==''){
		 alert('请假天数不能为空!');
		 $("#LeaveDay").focus(); 
		 return false;
	}
	if(!$("#LeaveDay").val().replace(/^[0-9]*$/g,'')==''){
		 alert('请假天数只能为数字!'); 
		 $("#LeaveDay").focus(); 
		 return false;
	}
	return true;
}


function renewcheckOK(){
	if($("#renewLeaveNo").val().replace(/^ +| +$/g,'')==''){
		 alert('请假编号不能为空!');
		 $("#renewLeaveNo").focus(); 
		 return false;
	}
	if(!$("#renewLeaveNo").val().replace(/^[0-9]*$/g,'')==''){
		 alert('请假编号只能为数字!'); 
		 $("#renewLeaveNo").focus(); 
		 return false;
	}
	if($("#renewEmployeeID").val().replace(/^ +| +$/g,'')==''){
		 alert('员工号不能为空!');
		 $("#renewEmployeeID").focus(); 
		 return false;
	}
	if(!$("#renewEmployeeID").val().replace(/^[0-9]*$/g,'')==''){
		 alert('员工号只能为数字!'); 
		 $("#renewEmployeeID").focus(); 
		 return false;
	}
	var hasEmployee=0;
	for(var i=0;i<employeeArray.length;i++){
		if(employeeArray[i]==$("#renewEmployeeID").val()){
			hasEmployee=1; break;
		}
	}
	if(hasEmployee==0){
		$("#renewEmployeeID").focus(); 
		alert("您输入的员工不存在");
		return false;
	}
	if($("#renewName").val().replace(/^ +| +$/g,'')==''){
		 alert('员工姓名不能为空!');
		 $("#renewName").focus(); 
		 return false;
	}
	if($("#renewDepartmentID").val().replace(/^ +| +$/g,'')==''){
		 alert('部门号不能为空!');
		 $("#renewDepartmentID").focus(); 
		 return false;
	}
	if(!$("#renewDepartmentID").val().replace(/^[0-9]*$/g,'')==''){
		 alert('部门号只能为数字!'); 
		 $("#renewDepartmentID").focus(); 
		 return false;
	}
	var hasDepartment=0;
	for(var i=0;i<departmentArray.length;i++){
		if(departmentArray[i]==$("#renewDepartmentID").val()){
			hasDepartment=1; break;
		}
	}
	if(hasDepartment==0){
		$("#renewDepartmentID").focus(); 
		alert("您输入的部门不存在");
		return false;
	}
	if($("#renewPositionID").val().replace(/^ +| +$/g,'')==''){
		 alert('岗位号不能为空!');
		 $("#renewPositionID").focus(); 
		 return false;
	}
	if(!$("#renewPositionID").val().replace(/^[0-9]*$/g,'')==''){
		 alert('岗位号只能为数字!'); 
		 $("#renewPositionID").focus(); 
		 return false;
	}
	var hasPosition=0;
	for(var i=0;i<positionArray.length;i++){
		if(positionArray[i]==$("#renewPositionID").val()){
			hasPosition=1; break;
		}
	}
	if(hasPosition==0){
		alert("您输入的岗位不存在");
		$("#renewPositionID").focus(); 
		return false;
	}
	if($("#renewLeaveReason").val().replace(/^ +| +$/g,'')==''){
		 alert('请假原因不能为空!');
		 $("#renewLeaveReason").focus(); 
		 return false;
	}
	if($("#renewLeaveTime").val().replace(/^ +| +$/g,'')==''){
		 alert('日期不能为空!');
		 $("#renewLeaveTime").focus(); 
		 return false;
	}
	if(!$("#renewLeaveTime").val().replace(/^\d{4}-\d{1,2}-\d{1,2}/g,'')==''){
		 alert('请按2000-01-01的格式输入日期');
		 $("#renewLeaveTime").focus(); 
		 return false;
	}
	if($("#renewLeaveDay").val().replace(/^ +| +$/g,'')==''){
		 alert('请假天数不能为空!');
		 $("#renewLeaveDay").focus(); 
		 return false;
	}
	if(!$("#renewLeaveDay").val().replace(/^[0-9]*$/g,'')==''){
		 alert('请假天数只能为数字!'); 
		 $("#renewLeaveDay").focus(); 
		 return false;
	}
	return true;
}

//输入员工号后同步员工姓名，岗位号，部门号
function ENPD(){
	var addsyn=setInterval(function(){
		if($("#EmployeeID").val()!=""&&!$("#EmployeeID").is(":focus")){
			var hasEmployee=0;
			for(var i=0;i<ENPD_Array.length;i++){
				if($("#EmployeeID").val()==ENPD_Array[i][0]){
					$("#Name").val(ENPD_Array[i][1]);
					$("#DepartmentID").val(ENPD_Array[i][2]);
					$("#PositionID").val(ENPD_Array[i][3]);
					hasEmployee=1;
					clearInterval(addsyn);
					break;
				}
			}
			clearInterval(addsyn);
		}
	},500);
	var renewsyn=setInterval(function(){
		if($("#renewEmployeeID").val()!=""&&!$("#renewEmployeeID").is(":focus")){
			for(var i=0;i<ENPD_Array.length;i++){
				if($("#renewEmployeeID").val()==ENPD_Array[i][0]){
					$("#renewName").val(ENPD_Array[i][1]);
					$("#renewDepartmentID").val(ENPD_Array[i][2]);
					$("#renewPositionID").val(ENPD_Array[i][3]);
					clearInterval(renewsyn);
					break;
				}
			}
		}
	},500);
}

//增加
function add(){
	$(".leave_table").scrollTop($("#leave_table_content").children().length*38);
	$("#LeaveNo").focus();
	$(document).keydown(function(e){
		var key=e.keyCode;
		if(key==13){
			if(addcheckOK()){
				var LeaveNo=$("#LeaveNo").val();
				var EmployeeID=$("#EmployeeID").val();
				/*var Name=$("#Name").val();
				var DepartmentID=$("#DepartmentID").val();
				var PositionID=$("#PositionID").val();*/
				var LeaveReason=$("#LeaveReason").val();
				var LeaveTime=$("#LeaveTime").val();
				var LeaveDay=$("#LeaveDay").val();
				$("#leave_table_content").append('<tr class="leave-'+LeaveNo+'"><td >'+LeaveNo+'</td><td >'+EmployeeID+'</td><td>'+$("#Name").val()+'</td><td >'+$("#DepartmentID").val()+'</td><td >'+$("#PositionID").val()+'</td><td >'+LeaveReason+'</td><td >'+LeaveTime+'</td><td >'+LeaveDay+'</td></tr>');
				$("#LeaveNo").val("");
				$("#LeaveNo").focus();
				$("#EmployeeID").val("");
				$("#Name").val("");
				$("#DepartmentID").val("");
				$("#PositionID").val("");
				$("#LeaveReason").val("");
				$("#LeaveTime").val("");
				$("#LeaveDay").val("");
				//输入后滚动条自动到底部
				$(".leave_table").scrollTop($(".leave_table").scrollTop()+100);
			}
		}
	})
}

//查找
function lookup(){
	//获取输入的部门号
	var input_text=$("#input_text").val();
	//指定行存在
	if($(".leave-"+input_text).length>0){
		//根据输入部门号跳转到指定的行
		var counts=$(".leave-"+input_text).prevAll().length;
		$(".leave_table").scrollTop((counts-4)*37);
		//指定行文字变红1.5秒
		$(".leave-"+input_text).css("color","#fF0000");	
		setTimeout(function(){
			$(".leave-"+input_text).css("color","#333");	
		},1500);
		
	}
	//指定行不存在，提示2秒
	else{
		$("#alert").removeClass("hide");
		setTimeout(function(){
			$("#alert").addClass("hide");
		},2000);
	}
	/*//清空输入框
	$("#input_text").val("");
	$("#input_text").focus();*/
}

//修改
function renew(){
	//获取输入的部门号
	var input_text=$("#input_text").val();
	//指定行存在
	if($(".leave-"+input_text).length>0){
		//1.记录原来的信息
		var texts=$(".leave-"+input_text).children();
		var LeaveNo=texts.eq(0).text();
		var EmployeeID=texts.eq(1).text();
		var Name=texts.eq(2).text();
		var DepartmentID=texts.eq(3).text();
		var PositionID=texts.eq(4).text();
		var LeaveReason=texts.eq(5).text();
		var LeaveTime=texts.eq(6).text();
		var LeaveDay=texts.eq(7).text();
		//2.将改行转化为文本框
		$(".leave-"+input_text).empty();
		$(".leave-"+input_text).append('<td><input type="text" class="form-control" id="renewLeaveNo"></td><td><input type="text" class="form-control" id="renewEmployeeID" onFocus="ENPD()"></td><td><input type="text" class="form-control" id="renewName" disabled></td><td><input type="text" class="form-control" id="renewDepartmentID" disabled></td><td><input type="text" class="form-control" id="renewPositionID" disabled></td><td><input type="text" class="form-control" id="renewLeaveReason"></td><td><input type="text" class="form-control" id="renewLeaveTime"></td><td><input type="text" class="form-control" id="renewLeaveDay"></td>');
		//3.在文本框中显示原来的信息
		$("#renewLeaveNo").focus();
		$("#renewLeaveNo").val(LeaveNo);
		$("#renewEmployeeID").val(EmployeeID);
		$("#renewName").val(Name);
		$("#renewDepartmentID").val(DepartmentID);
		$("#renewPositionID").val(PositionID);
		$("#renewLeaveReason").val(LeaveReason);
		$("#renewLeaveTime").val(LeaveTime);
		$("#renewLeaveDay").val(LeaveDay);
		$("#renewLeaveNo").blur(function(){
			if(LeaveNo!=$("#renewLeaveNo").val()&&$(".leave-"+$("#renewLeaveNo").val()).length>0){
			alert("出勤编号已存在");
			$("#renewLeaveNo").val(LeaveNo);
			$("#renewLeaveNo").focus();
			}
		})
		//4.文本框失去焦点时保存修改信息
		var time=setInterval(function(){
			if(!$("#renewLeaveNo").is(":focus")&&!$("#renewEmployeeID").is(":focus")&&!$("#renewName").is(":focus")&&!$("#renewDepartmentID").is(":focus")&&!$("#renewPositionID").is(":focus")&&!$("#renewLeaveReason").is(":focus")&&!$("#renewLeaveTime").is(":focus")&&!$("#renewLeaveDay").is(":focus")){
				if(renewcheckOK()){
					var LeaveNo=$("#renewLeaveNo").val();
					var EmployeeID=$("#renewEmployeeID").val();
					var Name=$("#renewName").val();
					var DepartmentID=$("#renewDepartmentID").val();
					var PositionID=$("#renewPositionID").val();
					var LeaveReason=$("#renewLeaveReason").val();
					var LeaveTime=$("#renewLeaveTime").val();
					var LeaveDay=$("#renewLeaveDay").val();
	
					$(".leave-"+input_text).empty();
					$(".leave-"+input_text).append('<td>'+LeaveNo+'</td><td>'+EmployeeID+'</td><td>'+Name+'</td><td>'+DepartmentID+'</td><td>'+PositionID+'</td><td>'+LeaveReason+'</td><td>'+LeaveTime+'</td><td>'+LeaveDay+'</td>');
					clearInterval(time);
					if(LeaveNo!=input_text){
						$(".leave-"+input_text).addClass("leave-"+LeaveNo);
						$(".leave-"+input_text).removeClass("leave-"+input_text);
					}
				}
			}
		},200);
	}
	//指定行不存在
	else{
		$("#alert").removeClass("hide");
		setTimeout(function(){
			$("#alert").addClass("hide");
		},2000);
		return;
	}
}

//删除
function delect(){
	//获取输入的部门号
	var input_text=$("#input_text").val();
	//指定行存在
	if($(".leave-"+input_text).length>0){
		//根据输入部门号跳转到指定的行，指定行文字变红
		var counts=$(".leave-"+input_text).prevAll().length;
		$(".leave_table").scrollTop((counts-4)*37);
		$(".leave-"+input_text).css("color","#fF0000");	
		//弹出框提问是否删除
		setTimeout(function(){
			if(confirm("是否确定删除")){
				$(".leave-"+input_text).remove();
			}
			else{
				$(".leave-"+input_text).css("color","#333");	
			}
		},500);
	}
	//指定行不存在
	else{
		$("#alert").removeClass("hide");
		setTimeout(function(){
			$("#alert").addClass("hide");
		},2000);
		return;
	}
}
	
